import express from 'express'
import 'dotenv/config'
import { pingRouter } from './src/routes/ping.router.js';
import { notasRouterV1 } from './src/routes/notas.router.v1.js';
import { logMiddleware } from './src/middlewares/logger.middleware.js';
import { authMiddleware } from './src/middlewares/auth.middleware.js';
import { authRouter } from './src/routes/auth.router.v1.js';
import { conectarBD } from './src/config/db_config.js';
import { notasAdminRouterV1 } from './src/routes/notas.admin.router.v1.js';
import { validarRolAdmin } from './src/middlewares/admin.validator.middleware.js';

const app = express();

app.use(express.json());

app.use(logMiddleware)

//Rutas publicas
app.use("/", pingRouter)
app.use("/v1", authRouter)

//Rutas privadas
app.use(authMiddleware)
app.use("/v1", notasRouterV1)
app.use("/v1/admin", validarRolAdmin, notasAdminRouterV1)



//conectate con la base de datos
conectarBD();

//Inicializamos el servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`)
})